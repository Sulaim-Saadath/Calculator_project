#include <stdio.h>
#include <math.h>

int main() {
    double result, num;
    char operator;

    // Display a title
    printf("========================================\n");
    printf("         ADVANCED CALCULATOR\n");
    printf("========================================\n");

    // Get the first number
    printf("\nEnter first number: ");
    scanf("%lf", &result);

    while (1) {
        printf("\n------------------------------\n");
        printf("Enter operator (+, -, *, /, %%, ^, s (sqrt), e (exit)): ");
        scanf(" %c", &operator);

        if (operator == 'e') {
            // Show the final result before exiting
            printf("\nFinal Result: %.2f\n", result);
            break;
        } 
        else if (operator == 's') {
            if (result >= 0) {
                result = sqrt(result);
                printf("Square root = %.2f\n", result);
            } else {
                printf("Error: Cannot calculate square root of a negative number\n");
            }
        } 
        else {
            printf("Enter next number: ");
            scanf("%lf", &num);

            switch (operator) {
                case '+':
                    result += num;
                    printf("Result: %.2f + %.2f = %.2f\n", result - num, num, result);
                    break;
                case '-':
                    result -= num;
                    printf("Result: %.2f - %.2f = %.2f\n", result + num, num, result);
                    break;
                case '*':
                    result *= num;
                    printf("Result: %.2f * %.2f = %.2f\n", result / num, num, result);
                    break;
                case '/':
                    if (num != 0) {
                        result /= num;
                        printf("Result: %.2f ÷ %.2f = %.2f\n", result * num, num, result);
                    } else {
                        printf("Error: Division by zero is not allowed\n");
                    }
                    break;
                case '%':
                    if ((int)num != 0) {
                        result = (int)result % (int)num;
                        printf("Result: %.0f %% %.0f = %.0f\n", result + (int)num, num, result);
                    } else {
                        printf("Error: Division by zero is not allowed\n");
                    }
                    break;
                case '^':
                    result = pow(result, num);
                    printf("Result: pow(%.2f, %.2f) = %.2f\n", result, num, result);
                    break;
                default:
                    printf("Invalid operator\n");
                    break;
            }
        }
    }

    // Final message
    printf("========================================\n");
    printf("     Thank you for using the calculator!\n");
    printf("========================================\n");

    return 0;
}