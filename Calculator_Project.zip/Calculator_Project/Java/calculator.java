import java.util.Scanner;
import java.lang.Math;

public class calculator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double result, num;
        char operator;

        // Display a title
        System.out.println("========================================");
        System.out.println("         ADVANCED CALCULATOR");
        System.out.println("========================================");

        // Get the first number
        System.out.print("\nEnter first number: ");
        result = sc.nextDouble();

        while (true) {
            System.out.println("\n------------------------------");
            System.out.print("Enter operator (+, -, *, /, %, ^, s (sqrt), e (exit)): ");
            operator = sc.next().charAt(0);

            if (operator == 'e') {
                // Show the final result before exiting
                System.out.printf("\nFinal Result: %.2f\n", result);
                break;
            }
            else if (operator == 's') {
                if (result >= 0) {
                    result = Math.sqrt(result);
                    System.out.printf("Square root = %.2f\n", result);
                } else {
                    System.out.println("Error: Cannot calculate square root of a negative number");
                }
            }
            else {
                System.out.print("Enter next number: ");
                num = sc.nextDouble();

                switch (operator) {
                    case '+':
                        result += num;
                        System.out.printf("Result: %.2f + %.2f = %.2f\n", result - num, num, result);
                        break;
                    case '-':
                        result -= num;
                        System.out.printf("Result: %.2f - %.2f = %.2f\n", result + num, num, result);
                        break;
                    case '*':
                        result *= num;
                        System.out.printf("Result: %.2f * %.2f = %.2f\n", result / num, num, result);
                        break;
                    case '/':
                        if (num != 0) {
                            result /= num;
                            System.out.printf("Result: %.2f ÷ %.2f = %.2f\n", result * num, num, result);
                        } else {
                            System.out.println("Error: Division by zero is not allowed");
                        }
                        break;
                    case '%':
                        if (num != 0) {
                            result = result % num;
                            System.out.printf("Result: %.2f %% %.2f = %.2f\n", result + num, num, result);
                        } else {
                            System.out.println("Error: Division by zero is not allowed");
                        }
                        break;
                    case '^':
                        result = Math.pow(result, num);
                        System.out.printf("Result: %.2f ^ %.2f = %.2f\n", result, num, result);
                        break;
                    default:
                        System.out.println("Invalid operator");
                        break;
                }
            }
        }

        // Final message
        System.out.println("========================================");
        System.out.println("     Thank you for using the calculator!");
        System.out.println("========================================");

        sc.close();
    }
}