import math
print("="*50)
print("\U0001F9EE SIMPLE CALCULATOR \U0001F9EE")
print("="*50)
# Get the first number
result = float(input("Enter first number: "))

while True:
    operator = input("Enter operator (+, -, *, /, %, ^, sqrt) or 'exit' to stop: ")
    
    if operator == 'exit':
        break
    elif operator == 'sqrt':
        if result >= 0:
            result = math.sqrt(result)
            print(f"Result: {result}")
        else:
            print("Error: Cannot calculate square root of a negative number")
    else:
        num = float(input("Enter next number: "))

        if operator == '+':
            result += num
        elif operator == '-':
            result -= num
        elif operator == '*':
            result *= num
        elif operator == '/':
            if num != 0:
                result /= num
            else:
                print("Error: Division by zero is not allowed")
                continue
        elif operator == '%':
            if num != 0:
                result %= num
            else:
                print("Error: Division by zero is not allowed")
                continue
        elif operator == '^':
            result = math.pow(result, num)
        else:
            print("Invalid operator")
            continue
        
        print(f"Result: {result}")

print("\n \U0001F3AF final Result:", result)
print("="*50)
print("\U0001F680 Thank you for using the calculator!")
print("="*50)
