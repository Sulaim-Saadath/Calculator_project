#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double result, num;
    char op;

    // Display a title
    cout << "========================================" << endl;
    cout << "         ADVANCED CALCULATOR" << endl;
    cout << "========================================" << endl;

    // Get the first number
    cout << "\nEnter first number: ";
    cin >> result;

    while (true) {
        cout << "\n------------------------------" << endl;
        cout << "Enter operator (+, -, *, /, %, ^, s (sqrt), e (exit)): ";
        cin >> op;

        if (op == 'e') {
            // Show the final result before exiting
            cout << "\nFinal Result: " << result << endl;
            break;
        } 
        else if (op == 's') {
            if (result >= 0) {
                result = sqrt(result);
                cout << "Square root = " << result << endl;
            } else {
                cout << "Error: Cannot calculate square root of a negative number" << endl;
            }
        } 
        else {
            cout << "Enter next number: ";
            cin >> num;

            switch (op) {
                case '+':
                    result += num;
                    cout << "Result: " << (result - num) << " + " << num << " = " << result << endl;
                    break;
                case '-':
                    result -= num;
                    cout << "Result: " << (result + num) << " - " << num << " = " << result << endl;
                    break;
                case '*':
                    result *= num;
                    cout << "Result: " << (result / num) << " * " << num << " = " << result << endl;
                    break;
                case '/':
                    if (num != 0) {
                        result /= num;
                        cout << "Result: " << (result * num) << " ÷ " << num << " = " << result << endl;
                    } else {
                        cout << "Error: Division by zero is not allowed" << endl;
                    }
                    break;
                case '%':
                    if ((int)num != 0) {
                        result = (int)result % (int)num;
                        cout << "Result: " << (result + (int)num) << " % " << num << " = " << result << endl;
                    } else {
                        cout << "Error: Division by zero is not allowed" << endl;
                    }
                    break;
                case '^':
                    result = pow(result, num);
                    cout << "Result: pow(" << result << ", " << num << ") = " << result << endl;
                    break;
                default:
                    cout << "Invalid operator" << endl;
                    break;
            }
        }
    }

    // Final message
    cout << "========================================" << endl;
    cout << "     Thank you for using the calculator!" << endl;
    cout << "========================================" << endl;

    return 0;
}